/*************
 Logistic Regression( logistic regression using gradient descent
 
 The code is used for embedding system
 
 CopyRight 2017/5/15 owner by xin Huang
 All Rights Reserved
 
 **************/

#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct
{
    double attriValue[3];
    int classLabel;
} DataSample;


const double alph = 1; //learning rate
const int attriNum = 3;//number of attribute
int sampNum = 912;

double atrriMinValue[attriNum];
double atrriMaxValue[attriNum];


int ReadData(int num_sample, DataSample * data, char *filex,char* filey)
{
	FILE *pFile;
    FILE *yFile;
	char buf[1024];
    char bufy[1024];
	pFile = fopen(filex,"r");
	if(pFile==NULL)
	{
		printf("the data file is not existing %s\n", filex);
		return -1;
	}

	int row = 0;    //data line
	int cloumn = 0; //data attribute
	//char delim[] = ",";//data delimiter
	char *tmpdata = NULL;//data cache
	
	while(!feof(pFile)&&row<num_sample)
	{
        //sampNum++;
		buf[0] = '\0';
		fgets(buf,1024,pFile);

		if( buf[strlen(buf)-1]=='\n' )
		{
			buf[strlen(buf)-1]='\0';
		}

		//the first column is non-used,and second column is class label;
		for( int column = 0;column<3;++column )
		{
			if( column==0 )
			{
				tmpdata = strtok(buf," ");
                data[row].attriValue[column]=atof(tmpdata);
                continue;
			}
			else if( column==1 )
			{
                tmpdata = strtok(NULL," ");
                data[row].attriValue[column]=atof(tmpdata);
			}
			else
			{
                tmpdata = strtok(NULL," ");
                data[row].attriValue[column]=atof(tmpdata);
            }
		}
		++row;

	}
    yFile = fopen(filey,"r");
    
    
    int rowy = 0;    //data line
    int cloumny = 0; //data attribute
    //char delim[] = ",";//data delimiter
    char *tmpdatay = NULL;//data cache
    
    while(!feof(yFile)&&rowy<num_sample)
    {
        bufy[0] = '\0';
        fgets(bufy,1024,yFile);
        
        if( bufy[strlen(bufy)-1]=='\n' )
        {
            bufy[strlen(bufy)-1]='\0';
        }
        
      
            tmpdatay = bufy;
            data[rowy].classLabel=atoi(tmpdatay);
        ++rowy;
        
    }
    close(yFile);
    close(pFile);
	return 1;
}

void Normalize( DataSample* data,int num_sample )
{
	//for normalization (x-xmin)/(xmax-xmin)

	//think about the first sample is none-loss
	//get the min and max value of each attribute without thinking about the loss atrribute
	for( int i=0;i<attriNum;++i )
	{
		atrriMinValue[i] = data[0].attriValue[i];
		atrriMaxValue[i] = data[0].attriValue[i];
	}
	
	for( int row = 1; row < 912; ++row ){
		for( int column = 0; column < attriNum; ++column )
		{
			if( data[row].attriValue[column] > atrriMaxValue[column] && (data[row].attriValue[column]+1000)>0.0001 )
				atrriMaxValue[column] = data[row].attriValue[column];

			if( data[row].attriValue[column] < atrriMinValue[column] && (data[row].attriValue[column]+1000)>0.0001 )
				atrriMinValue[column] = data[row].attriValue[column];
		}

	}

	for( int row = 0; row < num_sample; ++row )
		for( int column = 0; column < attriNum; ++column )
		{
			if( (data[row].attriValue[column]+1000)>0.0001)
				data[row].attriValue[column] = (data[row].attriValue[column]-atrriMinValue[column])/(atrriMaxValue[column]-atrriMinValue[column]);
			else
				data[row].attriValue[column] = 0;//set loss value 0;
		}
		for( int i=0;i<attriNum;++i )
	{
	}
}
//use newton gradient descent algorithm to get the w
//logistic model: 1/(1+exp(-z))
//class label
float compute_gradiant(int dim, DataSample* data, double *logisW ){
    double gradiant=0.0;
    
    double h = 0.0;
    double error = 0.0;

    for( int row=0; row<912; ++row )
    {	
        h = 0.0;
        for( int column=0; column<attriNum; ++column )
        {	
            h += data[row].attriValue[column]*logisW[column];
        }
        h += logisW[attriNum]*1;
        h = 1/(1+exp(-h));
        if(dim==3){
            error +=(h- (double) data[row].classLabel);
        }
        else{
            error +=(h- (double) data[row].classLabel)*data[row].attriValue[dim];
        }
        
    }
   

    gradiant = error/sampNum;
    
    return gradiant;
};
void Logistic( DataSample* data, double *logisW, int num_sample)
{


	for( int i=0;i<(attriNum+1);++i )
	{
		logisW[i] = 1.0;
	}
	
	
	Normalize( data,num_sample);

	double h = 0.0;
	double error = 0.0;
    int o=10000;
    while(o>0){
	        o--;
        for(int j=0;j<(attriNum+1);j++){
            logisW[j]-= alph*compute_gradiant(j, data,logisW);
        }
    }
    printf("%f\n", logisW[0]);
}

int Predict( float* sample, double *logisW )
{
	double h = 0.0;
	int label = 0;
	

	for( int column=0; column<attriNum; ++column )
	{
		sample[column] = (sample[column]-atrriMinValue[column])/(atrriMaxValue[column]-atrriMinValue[column]);
		h += sample[column]*logisW[column];
	}
	h += logisW[attriNum];
    h = 1/(1+exp(-h));
    if( h>0.5 )
    {
        label = 1;
    }
	else {
        label = 0;
    }
    return label;
}


#endif