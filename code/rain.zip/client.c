#include <sys/socket.h>
#include <wiringPi.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#define MAXTIMINGS  85 
#define DHTPIN      1
int dht11_dat[5] = { 0, 0, 0, 0, 0 };



uint8_t read_dht11_dat()
{
    uint8_t laststate   = HIGH;
    uint8_t counter     = 0;
    uint8_t j       = 0, i;
    float   f; /* fahrenheit */

    dht11_dat[0] = dht11_dat[1] = dht11_dat[2] = dht11_dat[3] = dht11_dat[4] = 0;

    /* pull pin down for 18 milliseconds */
    pinMode( DHTPIN, OUTPUT );
    digitalWrite( DHTPIN, LOW );
    delay( 18 );
    /* then pull it up for 40 microseconds */
    digitalWrite( DHTPIN, HIGH );
    delayMicroseconds( 40 );
    /* prepare to read the pin */
    pinMode( DHTPIN, INPUT );

    /* detect change and read data */
    for ( i = 0; i < MAXTIMINGS; i++ )
    {
        counter = 0;
        while ( digitalRead( DHTPIN ) == laststate )
        {
            counter++;
            delayMicroseconds( 1 );
            if ( counter == 255 )
            {
                break;
            }
        }
        laststate = digitalRead( DHTPIN );

        if ( counter == 255 )
            break;

        /* ignore first 3 transitions */
        if ( (i >= 4) && (i % 2 == 0) )
        {
            /* shove each bit into the storage bytes */
            dht11_dat[j / 8] <<= 1;
            if ( counter > 16 )
                dht11_dat[j / 8] |= 1;
            j++;
        }
    }

    /*
     * check we read 40 bits (8bit x 5 ) + verify checksum in the last byte
     * print it out if data is good
     */
    if ( (j >= 40) &&
         (dht11_dat[4] == ( (dht11_dat[0] + dht11_dat[1] + dht11_dat[2] + dht11_dat[3]) & 0xFF) ) )
    {
        f = dht11_dat[2] * 9. / 5. + 32;
        //printf( "Humidity = %d.%d %% Temperature = %d.%d *C (%.1f *F)\n",
          //  dht11_dat[0], dht11_dat[1], dht11_dat[2], dht11_dat[3], f );
    }else  {
        //printf( "Data not good, skip\n" );
    }
return j;
}

int main(int argc, char *argv[])
{
    if ( wiringPiSetup() == -1 )
        exit( 1 );

    int sockfd = 0, n = 0;
    char recvBuff[1024];
    struct sockaddr_in serv_addr; 

    if(argc != 2)
    {
        printf("\n Usage: %s <ip of server> \n",argv[0]);
        return 1;
    } 

    memset(recvBuff, '0',sizeof(recvBuff));
    if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("\n Error : Could not create socket \n");
        return 1;
    } 

    memset(&serv_addr, '0', sizeof(serv_addr)); 

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(5000); 

    if(inet_pton(AF_INET, argv[1], &serv_addr.sin_addr)<=0)
    {
        printf("\n inet_pton error occured\n");
        return 1;
    } 

    //connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
 
  while (1)
    {  
   uint8_t jj= read_dht11_dat();
 	if ( (jj >= 40) &&
         (dht11_dat[4] == ( (dht11_dat[0] + dht11_dat[1] + dht11_dat[2] + dht11_dat[3]) & 0xFF) ) )
    {
        float f = dht11_dat[2] * 9. / 5. + 32;
        printf( "Humidity = %d.%d %% Temperature = %d.%d *C (%.1f *F)\n",
           dht11_dat[0], dht11_dat[1], dht11_dat[2], dht11_dat[3], f );
  
	
    char hum1[100];
    char b[2]=".";
    char hum2[10];
    char d[5]=" ";
    char e[2]=" ";
    char tem1[10];
    char g[2]=".";
    char tem2[10];
    char i[5]="*C";
    char j[5]=" ";
    char pre[10]="1015"  ;
    char k[5]="\n" ; 
    sprintf(hum1,"%d",dht11_dat[0]);
    sprintf(hum2,"%d",dht11_dat[1]);
    sprintf(tem1,"%d",dht11_dat[2]);
    sprintf(tem2,"%d",dht11_dat[3]);

	//connect together
    strcat(hum1,b);
    strcat(hum1,hum2);
    strcat(hum1,d);
    strcat(hum1,tem1);
    strcat(hum1,g);
    strcat(hum1,tem2);
    strcat(hum1,j);
    strcat(hum1,pre);
    strcat(hum1,k);
  
   

   //send message
    printf("%s\n",hum1);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    printf("%d\n",connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)));
    memset(recvBuff,'0',sizeof(recvBuff));  
    strcpy(recvBuff,hum1);
    write(sockfd,recvBuff,strlen(recvBuff));
	printf("%d\n",write(sockfd,recvBuff,strlen(recvBuff)));
    sleep( 5 ); /* wait 5sec to refresh */
      }

}
  

    return 0;
}
