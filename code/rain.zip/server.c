#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h> 
#include <pthread.h>
#include "log2.h" 
#include <stdio.h>
#include <sys/time.h>
#include <wiringPi.h>
#include <softPwm.h>

#define MAX 10
#define uchar unsigned char
#define LedPinRed 6
#define LedPinGreen 5

pthread_mutex_t mut;
int number=0, i;
double logisW[4];
int modified = 1;
float data_test[3];
pthread_t thread[10];
int datalen=912;
int state=1;
int state_old ;
int change =1;
int semaphore =1;

void ledInit(void) {
	softPwmCreate(LedPinRed , 0, 100);
	softPwmCreate(LedPinGreen ,0, 100);

}

void ledColorSet(uchar r_val, uchar g_val) {
	softPwmWrite(LedPinRed, r_val);
	softPwmWrite(LedPinGreen, g_val);

}


int _System(const char * cmd, char *pRetMsg, int msg_len)  
{  
    FILE * fp;  
    char * p = NULL;  
    int res = -1;  
    if (cmd == NULL || pRetMsg == NULL || msg_len < 0)  
    {  
        printf("Param Error!\n");  
        return -1;  
    }  
    if ((fp = popen(cmd, "r") ) == NULL)  
    {  
        printf("Popen Error!\n");  
        return -2;  
    }  
    else  
    {  
        memset(pRetMsg, 0, msg_len);  
        //get lastest result  
        while(fgets(pRetMsg, msg_len, fp) != NULL)  
        {  
            printf("Msg:%s",pRetMsg); //print all info  
        }  
  
        if ( (res = pclose(fp)) == -1)  
        {  
            printf("close popenerror!\n");  
            return -3;  
        }  
        pRetMsg[strlen(pRetMsg)-1] = '\0';  
        return 0;  
    }  
}  
 
void* data_gathering(void)
{
while(1){
	if(semaphore ==1){
    char *cmd = "python whe.py";  
    char a8Result[128] = {0};  
    int rett = 0;  
    rett  = _System(cmd, a8Result, sizeof(a8Result));  
    if(a8Result[0]-'0'==1){
        printf("%d\n", datalen);
        datalen++;
    }
	sleep(300);
	}
    sleep(3);
  }
  pthread_exit ( NULL );
}


void *training(void ){
     semaphore = 0;
    DataSample *data=malloc(sizeof(DataSample)*datalen);
    ReadData(datalen,  data, "./x.txt","./y.txt");
    int i,j;
 	pthread_mutex_lock ( &mut );
    Logistic( data,logisW,datalen );   
    pthread_mutex_unlock ( &mut );
    free(data);
    semaphore = 1;
    pthread_exit ( NULL );

}


int predict(){
      return Predict(data_test,logisW);
}

void *display(){
	while(1){
	pthread_mutex_lock ( &mut );
	if (state==1)     {
     ledColorSet(0xff,0x00); 
      printf("rain!\n");
                        }                
    else if (state==0){
    
     ledColorSet(0x00,0xff);
                      printf("no rain!\n");
                         } 

  
    pthread_mutex_unlock ( &mut );
    sleep(10);
	}
}


 
int main()
{
	wiringPiSetup();
    ledInit();
ledColorSet(0xff,0x00); 
    pthread_mutex_init ( &mut,NULL );
 	int temp;

 	int listenfd = 0, connfd = 0;
    struct sockaddr_in serv_addr; 

    char sendBuff[1025];
    time_t ticks; 

    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    memset(&serv_addr, '0', sizeof(serv_addr));
    memset(sendBuff, '\0', sizeof(sendBuff)); 

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port = htons(5000); 

    bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)); 

    listen(listenfd, 10); 
    if ( ( temp = pthread_create ( &thread[0], NULL, training, NULL ) ) != 0 )  {}     //comment2
     //   printf ( "training fail !\n" );
 //   else
       // printf ( "training succeed !\n" ) ;
   //  pthread_join ( thread[0],NULL );
    if ( ( temp = pthread_create ( &thread[1], NULL, display, NULL ) ) != 0 )  {}     //comment2
    //    printf ( "training fail !\n" );
    	//else
     //   printf ( "training succeed !\n" );
     if ( ( temp = pthread_create ( &thread[2], NULL, data_gathering, NULL ) ) != 0 )  {}  
   		int iii=0;
    while(1)
    { 
    	iii++;
    	if ( thread[0]!=0 )                  //comment4
   	  	{
        pthread_join ( thread[0],NULL );
    	}
        connfd = accept(listenfd, (struct sockaddr*)NULL, NULL); 
        int n=read(connfd,sendBuff,sizeof(sendBuff));
		sendBuff[n]=0;
		pthread_mutex_lock ( &mut );
		data_test[0] = atof(strtok(sendBuff," "));
       		data_test[1] = atof(strtok(NULL," "));
 		data_test[2]= atof(strtok(NULL," "));
		//state_old =state;
 		state = predict();
		//if(state_old ==state){change =0;}
		//else{change = 1;}
 		pthread_mutex_unlock ( &mut );
 		printf("%d\n",state);
        close(connfd);
        sleep(1);
        if(iii%50000==0){
        	if ( ( temp = pthread_create ( &thread[0], NULL, training, NULL ) ) != 0 ){}       //comment2
        	//	printf ( "training fail !\n" );
   		//	else
        	//	printf ( "training succeed !\n" );
      		  if(iii==50000){iii=0;}
        }


     }

 
    return 0;
}


