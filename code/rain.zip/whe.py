import urllib2, urllib, json
baseurl = "https://query.yahooapis.com/v1/public/yql?"
yql_query_a = 'select item.condition , atmosphere from weather.forecast where woeid = 2151849'
yql_url_a = baseurl + urllib.urlencode({'q':yql_query_a}) + "&format=json"
result_a = urllib2.urlopen(yql_url_a).read()
data_a = json.loads(result_a)
if 2>1:
	aa =data_a['query']['results']
	temp = (float(aa['channel']['item']['condition']['temp'])-32.0)/1.8 
	pressure = aa['channel']['atmosphere']['pressure']
	humidity = aa['channel']['atmosphere']['humidity']
	condition = str(aa['channel']['item']['condition']['text']).lower()
	ifrain=["tornado","tropical storm","hurricane","severe thunderstorms",'thunderstorms',"mixed rain and snow"
	,"mixed rain and sleet","mixed snow and sleet","freezing drizzle","drizzle","freezing rain","showers","showers",
	"snow flurries","light snow showers","blowing snow","snow"]
	rain =0
	for weather in ifrain:
		if(condition==weather):
			rain =1
	print "1",temp,pressure,humidity,condition,rain
	aaa= open("./test_x.txt","a")
	aab = open("./test_y.txt","a")
	aaa.write(str(temp)+" "+str(humidity)+" "+str(pressure)+"\n")
	aab.write(str(rain)+"\n");
